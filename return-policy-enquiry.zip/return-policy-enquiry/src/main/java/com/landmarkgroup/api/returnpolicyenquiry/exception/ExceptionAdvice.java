package com.landmarkgroup.api.returnpolicyenquiry.exception;

import com.landmarkgroup.api.returnpolicyenquiry.service.ReturnPolicyValidationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import java.time.LocalDateTime;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.reactive.function.client.WebClientResponseException;

/*@ControllerAdvice(assignableTypes = ReturnPolicyValidationService.class)
public class ExceptionAdvice {

    @ExceptionHandler
    public ResponseEntity<String> handle(Exception ex){
        return ResponseEntity.status ( HttpStatus.NOT_FOUND).body(ex.getMessage ());
    }
}*/

@RestControllerAdvice
public class ExceptionAdvice {

    @ExceptionHandler(value = NotFoundException.class)
    public ResponseEntity<CustomErrorResponse> handleGenericNotFoundException(NotFoundException e) {
        CustomErrorResponse error = new CustomErrorResponse( e.getMessage(),"",HttpStatus.NOT_FOUND.value ());
        error.setHttpCode (HttpStatus.NOT_FOUND.value ());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = WebClientResponseException.InternalServerError.class)
    public ResponseEntity<CustomErrorResponse> handleGenericInternalServerErrorException(WebClientResponseException.InternalServerError e) {
        CustomErrorResponse error = new CustomErrorResponse(e.getMessage(),"",HttpStatus.INTERNAL_SERVER_ERROR.value ());
        error.setHttpCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(value = WebClientResponseException.Forbidden.class)
    public ResponseEntity<CustomErrorResponse> handleGenericForbiddenException(WebClientResponseException.Forbidden e) {
        CustomErrorResponse error = new CustomErrorResponse(e.getMessage(),"",HttpStatus.FORBIDDEN.value ());
        error.setHttpCode (HttpStatus.FORBIDDEN.value());
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(value = BadRequestException.class)
    public ResponseEntity<CustomErrorResponse> handleGenericBadRequestException(BadRequestException e) {
        CustomErrorResponse error = new CustomErrorResponse(e.getLocalizedMessage (),"",HttpStatus.BAD_REQUEST.value ());
        error.setHttpCode (HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<CustomErrorResponse> handleGenericException(Exception e) {
        CustomErrorResponse error = new CustomErrorResponse(e.getMessage(),"",HttpStatus.INTERNAL_SERVER_ERROR.value ());
        error.setHttpCode((HttpStatus.INTERNAL_SERVER_ERROR.value()));
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }


}