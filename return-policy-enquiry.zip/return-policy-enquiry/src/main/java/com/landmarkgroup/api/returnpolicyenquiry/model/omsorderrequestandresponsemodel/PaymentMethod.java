package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class PaymentMethod {

    @Field("payment_type")
    private String paymentType;

    private BigDecimal amount;

    @Field("payment_reference3")
    private String paymentReference3;

    @Field("payment_reference4")
    private String paymentReference4;


}

