package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnpolicydb")
public class SalesOrderLines {

    @NonNull
    @Field("ordered_quantity")
    private BigDecimal orderedQuantity;

    @NonNull
    @Field("department_code")
    private String departmentCode;

    @NonNull
    private String status;

    @NonNull
    private BigDecimal statusQty;

    @NonNull
    @Field("delivery_type")
    private String deliveryType;

    @Field("delivery_date")
    private String deliveryDate;

    @NonNull
    @Field("prime_line_number")
    private String primeLineNumber;

    @Field("sub_line_number")
    private String subLineNumber;

    @Field("item_type")
    private String itemType;

    @NonNull
    @Field("returnable_quantity")
    private BigDecimal returnableQuantity;

    @Field("is_returnable")
    private boolean isReturnable;

    @Field("return_window_period")
    private boolean returnWindowPeriod;

    @Field("within_returnWindow")
    private boolean withinReturnWindow;

    @Field("return_window_timePeriod")
    private BigDecimal returnWindowTimePeriod;

    @Field("line_charges")
    private List<LineCharge> lineCharges;

    @Field("line_taxes")
    private List<LineTax> lineTaxes;

    @Field("line_price_information")
    private List<LinePriceInformation> linePriceInformation;

    @Field("item_details")
    private ItemDetails itemDetails;

    @Field("order_statuses")
    private List<OrderStatus> orderStatuses;

}
